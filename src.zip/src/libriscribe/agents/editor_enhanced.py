import logging
from typing import Dict, Any
from libriscribe.agents.agent_base import Agent
from libriscribe.utils.llm_client import LLMClient
from libriscribe.utils.prompt_integration import ExternalPromptMixin
from libriscribe.utils import prompts_context as prompts
from rich.console import Console

console = Console()
logger = logging.getLogger(__name__)


class EnhancedEditorAgent(Agent, ExternalPromptMixin):
    """Editor agent that now supports reviewer feedback for a second pass."""

    def __init__(self, llm_client: LLMClient):
        Agent.__init__(self, "EnhancedEditorAgent", llm_client)
        ExternalPromptMixin.__init__(self)

    def execute(
        self,
        chapter_number: int,
        chapter_content: str,
        actionable_feedback: str = "",
        genre: str = "fiction",
        book_title: str = "Untitled",
        language: str = "English",
        **kwargs
    ) -> Dict[str, Any]:

        prompt_data = {
            "genre": genre,
            "book_title": book_title,
            "language": language,
            "chapter_number": chapter_number,
            "chapter_title": f"Chapter {chapter_number}",
            "chapter_content": chapter_content,
            "review_feedback": actionable_feedback or "No reviewer feedback provided."
        }

        console.print(f"✏️ [cyan]Rewriting Chapter {chapter_number} using reviewer feedback...[/cyan]")

        edited = self.generate_with_external_prompt(
            prompt_name="editor",
            fallback_prompt=prompts.EDITOR_PROMPT,
            prompt_data=prompt_data,
            default_max_tokens=8000
        )

        console.print(f"📘 [green]Chapter {chapter_number} re-edited successfully[/green]")

        return {"edited_content": edited}
